<?php
    error_reporting(0);
    include 'koneksi.php';

if (isset($_GET['id'])) {

    $id_p = $_GET['id'];
    $file = mysqli_query($koneksi, "SELECT foto FROM set_data where admin = '$id_p'");
   

    $query = "DELETE FROM set_data where admin = '$id_p'";
    $result = mysqli_query($koneksi, $query);

    if (!$result) 
    {
        die("Data gagal di tambahkan;". mysqli_errno($koneksi).mysqli_error($koneksi));
    } 
    else 
    {
        echo "<script>
                alert('Data Berhasil Dihapus !');
                window.location.href='share.php';
              </script>";
    }
}
?>