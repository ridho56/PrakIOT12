<?php
error_reporting(0);
include 'koneksi.php';

if(isset($_POST['edit'])){
	$id_p =$row["id_p"];
	$nama_p = $row["nama_p"];
    $humidity_p = $row["humidity_p"];
    $temperature_p = $row["temperature_p"];
    $waktu_input = $row["waktu_input"];
	
	


	$query = "UPDATE set_data set nama_p = '$nama_p', humidity_p = '$humidity_p', temperature_p = '$temperature_p', waktu_input = '$waktu_input' where admin = '$id_p' ";
	$result = mysqli_query ($koneksi, $query);

	if (!$result){
		die("Data gagal di ubah; ".mysqli_errno($koneksi).mysqli_error($koneksi));
	}
	else{
		echo "<script>alert('Data Berhasil Diubah');window.location.href='share.php'</script>";
	}
}
?>