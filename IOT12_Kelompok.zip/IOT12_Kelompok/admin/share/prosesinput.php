<?php
error_reporting(0);
include 'koneksi.php';

if (isset($_POST['simpan'])){

    $id_p = $row["id_p"];
    $nama_p = $row["nama_p"];
    $humidity_p = $row["humidity_p"];
    $temperature_p = $row["temperature_p"];
    $waktu_input = $row["waktu_input"];
	
   

    
        $query = "INSERT INTO set_data VALUES ('$id_p','$nama_p','$humidity_p','$temperature_p','$waktu_input')";
        $result = mysqli_query($koneksi, $query);
        if (!$result) {
            die("Query Gagal dijalankan : " . mysqli_errno($koneksi)." - ". mysqli_error($koneksi));        
        }
        else
        {
            echo "<script>
            alert('Data Berhasil Ditambah');window.location.href='share.php'</script>";
        }
        
    
}

 ?>