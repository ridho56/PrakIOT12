<!doctype html>
<html lang="en">
<?php

    include 'koneksi.php';
?>
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="admins.css">
    <link rel="stylesheet" type="text/css" href="fontawesome/css/all.min.css">
    <title>Selamat Datang</title>
  </head>
 
  <div class="row no-gutters ">
      <div class="col-md-2 mt-1 pr-3 pt-4">
        <ul class="nav flex-column ml-3 mb-5">
          <li class="nav-item">
            <a class="nav-link active text-white" href="#"><i class="fas fa-tachometer-alt mr-2"></i> Dashboard</a><hr class="">
        </li>
  <li class="nav-item">
      <a class="nav-link text-white" href="share/share.php"><i class="fas fa-share-alt-square mr-2"></i> Editing</a><hr class="">
  </li>
  
  <li class="nav-item">
      <a class="nav-link text-white" href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a><hr class="">
  </li>
</ul>
    </div>
    <body>
        <div class="col-md-10 p-5 pt-2" >
            <h3><i class="fas fa-tachometer-alt mr-2" style=color:white></i>DASHBOARD</h3><hr>

  <div class="row">
      <?php
            $no=0;
            $result = mysqLi_query($koneksi,"SELECT * FROM set_data join humidity_p join temperature_p");
            while($row = mysqli_fetch_array($result)){
                $no++
            ?>
            
            <div class="card" style="width: 320px;">
  <div class="row no-gutters">
    <div class="col-md-4">
<br>
                            
                            
    </div>
    <div class="col-md-12">
      <div class="card-body">
      <div class="card-body bg-light">
          <div class="card-body bg-info">
            <h4 class="card-text" style=color:white><?php echo $no;?>. <?php echo $row['nama_p'];?></h4>
          </div>
          <div class="card-body bg-dark">
            <h4 class="card-text" style=color:white>Temperature : <?php echo $row['Humidity'];?></h4>
          </div>
          <div class="card-body bg-secondary">
            <h4 class="card-title" style=color:navajowhite>Hunidity : <?php echo $row['Temperature'];?></h4>
            </div>
            <div class="card-body bg-primary">
            <h4 class="card-title" style=color:navajowhite>Hunidity : <?php echo $row['Waktu'];?></h4>
            </div>
      </div>
      </div>
    </div>
  </div>
</div>
      <?php } ?>  
</div>
      </div>
    </div>
  </div>
  
</body>
</html>