-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2021 at 07:12 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `suhu`
--

-- --------------------------------------------------------

--
-- Table structure for table `donasi`
--

CREATE TABLE `donasi` (
  `admin` varchar(255) NOT NULL,
  `nama` varchar(250) NOT NULL,
  `deskripsi` mediumtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donasi`
--

INSERT INTO `donasi` (`admin`, `nama`, `deskripsi`) VALUES
('kulkas', '89', '95'),
('lemari', '56', '78'),
('mejikom', '100', '78'),
('termos', '76', '90');

-- --------------------------------------------------------

--
-- Table structure for table `humidity_p`
--

CREATE TABLE `humidity_p` (
  `id` int(5) NOT NULL,
  `id_penyimpanan` varchar(3) NOT NULL,
  `Waktu` datetime NOT NULL,
  `Humidity` varchar(255) NOT NULL,
  `humid_before` varchar(5) NOT NULL,
  `Action` varchar(255) NOT NULL,
  `nilai` varchar(255) NOT NULL,
  `waktu_perbaikan` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `humidity_p`
--

INSERT INTO `humidity_p` (`id`, `id_penyimpanan`, `Waktu`, `Humidity`, `humid_before`, `Action`, `nilai`, `waktu_perbaikan`) VALUES
(1, '1', '2019-06-05 00:00:00', '50', '2019', 'Kadar Kelembapan dinaikkan', '', '2019-06-29 15:25:46'),
(2, '1', '2019-06-10 03:41:05', '50', '2019', 'Kadar Kelembapan dinaikkan', '', '2019-06-29 14:50:17'),
(5, '1', '2021-11-24 08:18:45', '55', '', '', '', '0000-00-00 00:00:00'),
(6, '1', '2021-11-24 08:47:02', '31', '', '', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `set_data`
--

CREATE TABLE `set_data` (
  `id_p` int(10) NOT NULL,
  `nama_p` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `set_data`
--

INSERT INTO `set_data` (`id_p`, `nama_p`) VALUES
(1, 'Frezer'),
(2, 'mejikom');

-- --------------------------------------------------------

--
-- Table structure for table `temperature_p`
--

CREATE TABLE `temperature_p` (
  `id` int(5) NOT NULL,
  `id_penyimpanan` varchar(3) NOT NULL,
  `Waktu` datetime NOT NULL,
  `Temperature` varchar(255) NOT NULL,
  `temp_before` varchar(3) NOT NULL,
  `Action` varchar(255) NOT NULL,
  `nilai` varchar(255) NOT NULL,
  `waktu_perbaikan` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temperature_p`
--

INSERT INTO `temperature_p` (`id`, `id_penyimpanan`, `Waktu`, `Temperature`, `temp_before`, `Action`, `nilai`, `waktu_perbaikan`) VALUES
(1, '1', '2019-06-05 00:00:00', '27', '22', 'Suhu dinaikkan', '', '2019-06-29 15:30:36'),
(2, '1', '2019-06-10 03:41:05', '27', '30', 'suhu diturunkan', '10', '2019-08-22 16:03:32');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `level` varchar(32) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `level`, `password`) VALUES
(29, 'baskaraid', 'phindabaskara@gmail.com', 'Admin', '5138ecb5934c0cfbc5fbb14495d46514'),
(30, 'phindabaskara', 'basuki@gmail.com', 'Admin', 'e807f1fcf82d132f9bb018ca6738a19f'),
(31, 'zulfikar', 'ahmadizulfikar123@gmail.com', 'Pengguna', '25d55ad283aa400af464c76d713c07ad'),
(32, 'admin', 'rika123@gmail.com', 'Admin', 'e0e58e22350c06fd9465f29741c96b4a');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donasi`
--
ALTER TABLE `donasi`
  ADD PRIMARY KEY (`admin`);

--
-- Indexes for table `humidity_p`
--
ALTER TABLE `humidity_p`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `set_data`
--
ALTER TABLE `set_data`
  ADD PRIMARY KEY (`id_p`);

--
-- Indexes for table `temperature_p`
--
ALTER TABLE `temperature_p`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `humidity_p`
--
ALTER TABLE `humidity_p`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `set_data`
--
ALTER TABLE `set_data`
  MODIFY `id_p` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `temperature_p`
--
ALTER TABLE `temperature_p`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
